<?php
include("install.php");
?>